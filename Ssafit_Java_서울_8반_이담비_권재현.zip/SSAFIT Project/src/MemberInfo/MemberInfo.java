package MemberInfo;

public interface MemberInfo {

	public void regist(Member member) throws Throwable;
}
